import logo from './logo.svg';
import './App.css';
import Login from './LoginPortal/Login';
import ManagerLogin from './Manager/ManagerLogin';
import EmpDashBoard from './Emp/EmpDashBoard';
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';
import EmpLogin from './Emp/EmpLogin';


function App() {
  return (
    <div className="App">
     <BrowserRouter>
            
            {/* <Link to="/EmpDashBoard">EmpDashBoard</Link><br></br> */}
            <Routes>
              <Route path="/" element={<Login/>}></Route>
            <Route path="/ManagerLogin" element={<ManagerLogin/>}></Route>
                {/* <Route path="/EmpDashBoard" element={<EmpDashBoard/>}></Route> */}
                <Route path="/EmpLogin" element={<EmpLogin/>}></Route>
            </Routes>
    </BrowserRouter> 
    </div>
  );
}

export default App;
