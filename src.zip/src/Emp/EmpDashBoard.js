import React, { Component } from 'react'

export default class EmpDashBoard extends Component {
    render() {
        return (
            <div>
                DashBoard
            </div>
        )
    }
}
